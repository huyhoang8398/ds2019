import socket
import time
ETH_P_ALL = 3
interface = 'lo'
dst = b'\x08\x00\x27\xdd\xd7\x43'  # destination MAC address
src = b'\x08\x00\x27\x8e\x75\x44'  # source MAC address
proto = b'\x88\xb5'                # ethernet frame type
# print (payload)
payload = input()
command = ('command'+payload).encode()
print (command)
# while True:
s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(ETH_P_ALL))
s.bind((interface, 8080))
s.sendall(dst + src + proto + command)
# s.recv(1514)
# s.sendall(payload)
s.close()
# time.sleep(0.9)
# print ('gui ')
